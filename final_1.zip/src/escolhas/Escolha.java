package escolhas;

public interface Escolha {

    void executar();
}
