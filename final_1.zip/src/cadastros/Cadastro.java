package cadastros;

public interface Cadastro{
     void adicionar();
}
