package sistema_academico;

public class Texts {

    public static void initial_text()
    {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("    ----- Bem vindo ao Sistema de Gestão de Produtividade Acadêmica -----");
        System.out.println();
        System.out.println("[1] - Cadastrar Alunos;");
        System.out.println("[2] - Cadastrar Funcionários;");
        System.out.println("[3] - Cadastrar Professores;");
        System.out.println("[4] - Cadastrar Recusos físicos;");
        System.out.println("[5] - Despesas;");
        System.out.println("[6] - Eventos;");
        System.out.println("[7] - Printar professores;");
        System.out.println("[8] - Printar Recursos físicos;");
        System.out.println("[9] - Printar alunos;");
        System.out.println("[10] - Printar Funcionários;");
        System.out.println("[11] - Printar Despesas;");
        System.out.println("[12] - Printar eventos;");
        System.out.println("[13] - Editar dados alunos;");
        System.out.println("[14] - Editar dados funcionarios;");
        System.out.println("[15] - Editar dados professor;");
        System.out.println("[16] - Editar dados recursos físicos;");
        System.out.println("[17] - Remover evento;");
        System.out.println("[18] - Remover aluno;");
        System.out.println("[19] - Remover funcionario;");
        System.out.println("[20] - Remover professor;");
        System.out.println("[0] - Sair;");
        System.out.println();
    }

    public static void recursoTexto()
    {
        System.out.println("Digite a opção que você deseja editar:");
        System.out.println("[1] - Onibus (sim ou não)");
        System.out.println("[2] - Quantidade de ônibus");
        System.out.println("[3] - Quadra (sim ou não)");
        System.out.println("[4] - Quantidade de quadras");
        System.out.println("[5] - Piscina (sim ou não)");
        System.out.println("[6] - Quantidade de piscinas");
        System.out.println("[7] - Sala de música (sim ou não)");
        System.out.println("[8] - Quantidade de salas de músicas");
        System.out.println("[9] - Teatro (sim ou não)");
        System.out.println("[10] - Quantidade de salas de teatro");
        System.out.println("[11] - Biblioteca (sim ou não)");
        System.out.println("[12] - Quantidade de bibliotecas");
        System.out.println("[13] - Lanchonete (sim ou não)");
        System.out.println("[14] - Quantidade de lanchonetes");
        System.out.println("[0] - Voltar");
    }
}
