package sistema_academico;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Menu_principal 
{
    
    public static void main(String[] args) 
    {
        java.util.ArrayList<Alunos> Aluno = new java.util.ArrayList<Alunos>();
        java.util.ArrayList<Funcionarios> Funcionario = new java.util.ArrayList<Funcionarios>();
        java.util.ArrayList<Professores> Professor = new java.util.ArrayList<Professores>();
        java.util.ArrayList<Recursos_fisicos> Recurso_fisico = new java.util.ArrayList<Recursos_fisicos>();
        java.util.ArrayList<Despesas> Despesa = new java.util.ArrayList<Despesas>();
        java.util.ArrayList<Eventos> Evento = new java.util.ArrayList<Eventos>();
        
        
        System.out.println("    ----- Bem vindo ao Sistema de Gestão de Produtividade Acadêmica -----");
        System.out.println();
        System.out.println("[1] - Cadastrar Alunos;");
        System.out.println("[2] - Cadastrar Funcionários;");
        System.out.println("[3] - Cadastrar Professores;");
        System.out.println("[4] - Cadastrar Recusos físicos;");
        System.out.println("[5] - Printar alunos;");
        System.out.println("[6] - Printar Funcionários;");
        System.out.println("[7] - Printar professores;");
        System.out.println("[8] - Printar Recusros físicos;");
        System.out.println("[9] - Despesas;");
        System.out.println("[10] - Eventos;");
        System.out.println("[11] - Printar Despesas;");
        System.out.println("[12] - Printar eventos;");
        System.out.println("[13] - Editar dados alunos;");
        System.out.println("[14] - Editar dados funcionarios;");
        System.out.println("[15] - Editar dados professor;");
        System.out.println("[16] - Editar dados recursos físicos;");
        System.out.println("[17] - Remover evento;");
        
        System.out.println();
        Scanner input = new Scanner(System.in);
        int opcao = input.nextInt();
        input.nextLine();
        

        while(opcao != 0)
        {
            
            if(opcao == 1)
            {
                
                System.out.println("Digite o nome do aluno:");
                String nome = input.nextLine();
                System.out.println();
                System.out.println("Digite o número de matricula do aluno:");
                String numero_matricula = input.nextLine();
                System.out.println();
                System.out.println("Digite a série do aluno:");
                String serie_atual = input.nextLine();
                System.out.println();
                System.out.println("Digite a idade do aluno:");
                String idade = input.nextLine();
                System.out.println("Digite o E-mail do aluno:");
                String email = input.nextLine();
                System.out.println();
                System.out.println("Digite o coeficiente do aluno:");
                String coeficiente_aluno = input.nextLine();
                System.out.println();
                System.out.println("Digite a condição do aluno(aprovado ou reprovado):");
                String condicao_aluno = input.nextLine();
                System.out.println();
                System.out.println("Digite o telefone do aluno:");
                String telefone = input.nextLine();
                System.out.println();
                Alunos aluno = new Alunos(nome,idade,email, telefone,serie_atual,coeficiente_aluno, condicao_aluno,numero_matricula);
                if(aluno.search_aluno(Aluno, numero_matricula) == -1)
                {
                    Aluno.add(aluno);
                }
                else
                {
                    System.out.println("O aluno com os dados informados ja está cadastrado! \n Por favor, tente novamente;");
                }
                
                
            }
            else if(opcao == 2)
            {
                System.out.println("Digite o nome do funcionário:");
                String nome = input.nextLine();
                System.out.println();
                System.out.println("Digite a idade do funcionário:");
                String idade = input.nextLine();
                System.out.println("Digite o E-mail do funcionário:");
                String email = input.nextLine();
                System.out.println();
                System.out.println("Digite o salário do funcionário:");
                String salario = input.nextLine();
                System.out.println();
                System.out.println("Digite a profissão do funcionário:");
                String profissao = input.nextLine();
                System.out.println();
                System.out.println("Digite o telefone do funcionário:");
                String telefone = input.nextLine();
                System.out.println();
                System.out.println("Digite o cpf do funcionário:");
                String cpf = input.nextLine();
                System.out.println();
                Funcionarios funcionario = new Funcionarios(nome,idade,email,telefone,salario,profissao,cpf);
                if(funcionario.search_funcionario(Funcionario, cpf) == -1)
                {
                    Funcionario.add(funcionario);
                }
                else
                {
                    System.out.println("O funcionário com os dados informados já está cadastrado! \n Por favor, tente novamente;\n");
                }
            }
            else if(opcao == 3)
            {
                System.out.println("Digite o nome do professor:");
                String nome = input.nextLine();
                System.out.println();
                System.out.println("Digite o CPF do professor:");
                String cpf = input.nextLine();
                System.out.println();
                System.out.println("Digite a idade do professor:");
                String idade = input.nextLine();
                System.out.println("Digite o E-mail do professor:");
                String email = input.nextLine();
                System.out.println();
                System.out.println("Digite o salário do professor:");
                String salario = input.nextLine();
                System.out.println();
                System.out.println("Digite a graduação do professor:");
                String graduacao = input.nextLine();
                System.out.println();
                System.out.println("Digite o telefone do professor:");
                String telefone = input.nextLine();
                System.out.println();
                Professores professor = new Professores(nome,cpf,idade,email,salario,graduacao,telefone);
                if(professor.search_professor(Professor, cpf) == -1)
                {
                    Professor.add(professor);
                }
                else
                {
                    System.out.println("O professor com os dados informados já está cadastrado! \n Por favor, tente novamente;\n");
                }
               
            }
            else if(opcao == 4)
            {
                int quan_onibus=0, quan_sala_musica=0;
                int quan_quadra=0, quan_teatro=0;
                int quan_piscina=0,quan_biblioteca=0,quan_lanchonete=0;
                System.out.println("       ------- Recursos fisicos -------");
                System.out.println(" -- Ônibus --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String onibus = input.nextLine();
                if(onibus.equals( "SIM" ) || onibus.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de ônibus");
                    quan_onibus = input.nextInt();            
                }
                input.nextLine();
                System.out.println(" -- Quadras --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String quadra = input.nextLine();
                if(quadra.equals( "SIM" ) || quadra.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de Quadras");
                    quan_quadra = input.nextInt();            
                }
                input.nextLine();
                System.out.println(" -- Piscina --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String piscina = input.nextLine();
                if(piscina.equals( "SIM" ) || piscina.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de piscinas");
                    quan_piscina = input.nextInt();            
                }
                input.nextLine();
                System.out.println(" -- Sala de música --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String sala_musica = input.nextLine();
                if(sala_musica.equals( "SIM" ) || sala_musica.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de salas de músicas");
                    quan_sala_musica = input.nextInt();            
                }
                input.nextLine();
                System.out.println(" -- Teatro --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String teatro = input.nextLine();
                if(teatro.equals( "SIM" ) || teatro.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de teatros");
                    quan_teatro = input.nextInt();            
                }
                input.nextLine();
                System.out.println(" -- Biblioteca --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String biblioteca = input.nextLine();
                if(biblioteca.equals( "SIM" ) || biblioteca.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de bibliotecas");
                    quan_biblioteca = input.nextInt();            
                }
                input.nextLine();
                System.out.println(" -- Lanchonete --");
                System.out.println("[sim] - EXITE");
                System.out.println("[nao] - NÃO EXITE");
                String lanchonete = input.nextLine();
                if(lanchonete.equals( "SIM" ) || lanchonete.equals( "sim" ))
                {
                    System.out.println("Digite a quantidade de lanchonetes");
                    quan_lanchonete = input.nextInt();            
                }
                Recursos_fisicos recurso = new Recursos_fisicos(onibus, quan_onibus, quadra, quan_quadra, piscina,  quan_piscina, sala_musica, quan_sala_musica, teatro,quan_teatro, biblioteca,  quan_biblioteca,lanchonete, quan_lanchonete);

                Recurso_fisico.add(recurso);                 
            }
            else if(opcao == 5)
            {
                Alunos aluno = new Alunos();
                aluno.printaalunos(Aluno);
            }
            else if(opcao == 6)
            {
                Funcionarios funcionario = new Funcionarios();
                funcionario.printafuncionarios(Funcionario);
            }
            else if(opcao == 7)
            {
                Professores professor = new Professores();
                professor.printaprofessores(Professor);
            }
            else if(opcao == 8)
            {
                Recursos_fisicos recurso = new Recursos_fisicos();
                recurso.printarecursos(Recurso_fisico);
            }
            else if(opcao == 9)
            {
                System.out.println("Digite os valores das despesas correspondentes:");
                System.out.println("Digite a conta de energia:");
                float energia = input.nextFloat();
                System.out.println();
                System.out.println("Digite a conta de água:");
                float agua = input.nextFloat();
                System.out.println();
                System.out.println("Digite a conta de despesas de materiais escolares:");
                System.out.println();
                System.out.println("Materiais esportivos:");
                float mat_esportivos = input.nextFloat();
                System.out.println();
                System.out.println("Materiais didáticos");
                float mat_didaticos = input.nextFloat();
                System.out.println();
                System.out.println("Materiais de limpeza");
                float mat_limpeza = input.nextFloat();
                System.out.println();
                Despesas despesa = new Despesas(energia,agua,mat_esportivos,mat_didaticos,mat_limpeza);
                Despesa.add(despesa);
            }
            else if(opcao == 10)
            {
                System.out.println("Digite quantos eventos estão previstos:");
                int quant_eventos = input.nextInt();
                input.nextLine();
                for(int i = 0; i < quant_eventos ; i++)
                {
                    System.out.println();
                    System.out.println("Digite o nome do evento:");
                    String nome = input.nextLine();
                    System.out.println("Digite a data do evento:");
                    String data = input.nextLine();
                    Eventos evento = new Eventos(nome,data);
                    Evento.add(evento);
                }
            }
            else if(opcao == 11)
            {
                Despesas despesa = new Despesas();
                despesa.printadespesas(Despesa);
            }
            else if(opcao == 12)
            {
                Eventos evento = new Eventos();
                evento.printaeventos(Evento);
            }
            else if(opcao == 13)
            {
                Alunos aluno = new Alunos();
                aluno.menu_editaaluno(Aluno);
            }
            else if(opcao == 14)
            {
                Funcionarios funcionario = new Funcionarios();
                funcionario.menu_editafuncionario(Funcionario);
            }
            else if(opcao == 15)
            {
                Professores professor = new Professores();
                professor.menu_editaprofessor(Professor);
            }
            else if(opcao == 16)
            {
                Recursos_fisicos recurso_fisico = new Recursos_fisicos();
                recurso_fisico.menu_editarecurso(Recurso_fisico);
            }
                    
            System.out.println("[1] - Cadastrar Alunos;");
            System.out.println("[2] - Cadastrar Funcionários;");
            System.out.println("[3] - Cadastrar Professores;");
            System.out.println("[4] - Cadastrar Recusos físicos;");
            System.out.println("[5] - Printar alunos;");
            System.out.println("[6] - Printar Funcionários;");
            System.out.println("[7] - Printar professores;");
            System.out.println("[8] - Printar Recusros físicos;");
            System.out.println("[9] - Despesas;");
            System.out.println("[10] - Eventos;");
            System.out.println("[11] - Printar Despesas;");
            System.out.println("[12] - Printar eventos;");
            System.out.println("[13] - Editar dados alunos;");
            System.out.println("[14] - Editar dados funcionarios;");
            System.out.println("[15] - Editar dados professor;");
            System.out.println("[16] - Editar dados recursos físicos;");
            System.out.println();
            opcao = input.nextInt();
            input.nextLine();
        }
    }

    
    
}
