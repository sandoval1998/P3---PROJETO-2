
package sistema_academico;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Funcionarios extends Pessoas
{
    private String cpf;
    private String salario;
    private String profissao;
    
    Scanner input = new Scanner(System.in);
    
    public Funcionarios(String nome,String idade,String email,String telefone,String salario,String profissao,String cpf)
    {
        this.nome = nome;
        this.idade = idade;
        this.email = email;
        this.salario = salario;
        this.profissao = profissao;
        this.cpf = cpf;
        this.telefone = telefone; 
        //Professor.add(professor);       
        
    }
    public Funcionarios()
    {
        
    }
    
    public int search_funcionario(java.util.ArrayList<Funcionarios> Funcionario, String cpf) 
    {
        int z, local = -1;
        for (z = 0; z < Funcionario.size(); z++) {
            if (Funcionario.get(z).getCpf().equals(cpf)) {
                local = z;
            }
        }
        return local;
    }
    
     public static void printafuncionarios(java.util.ArrayList<Funcionarios> Funcionario)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o numero do CPF do funcionário:");
        String cpf;
        Funcionarios funcionario = new Funcionarios();
        cpf = input.nextLine();
        System.out.println();
        int local = funcionario.search_funcionario(Funcionario, cpf);
        if (local != -1) 
        {
            System.out.println("Nome: " + Funcionario.get(local).getNome());
            System.out.println("Idade: " + Funcionario.get(local).getIdade());
            System.out.println("Email: " + Funcionario.get(local).getEmail());
            System.out.println("Telefone: " + Funcionario.get(local).getTelefone());            
            System.out.println("CPF: " + Funcionario.get(local).getCpf());
            System.out.println("Salário: " + Funcionario.get(local).getSalario());
            System.out.println("Profissão: " + Funcionario.get(local).getProfissao());
        }
        else
        {
            System.out.println("Funcionário não cadastrado ou número da matricula não encontrado");
        }
    }
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }
    
    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }
}
