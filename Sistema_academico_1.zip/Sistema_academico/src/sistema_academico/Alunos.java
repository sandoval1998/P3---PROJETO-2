
package sistema_academico;

import java.util.ArrayList;
import java.util.Scanner;

public class Alunos extends Pessoas
{
    
    public String serie_atual;
    public String coeficiente_aluno;
    public String condicao_aluno;
    public String numero_matricula;
    
    Scanner input = new Scanner(System.in);
    
    public Alunos(String nome,String idade,String email,String telefone,String serie_atual,String coeficiente_aluno,String condicao_aluno, String numero_matricula)
    {
        this.nome = nome;
        this.idade = idade;
        this.email = email;
        this.serie_atual = serie_atual;
        this.coeficiente_aluno = coeficiente_aluno;
        this.condicao_aluno = condicao_aluno;
        this.telefone = telefone; 
        this.numero_matricula = numero_matricula;
        //Professor.add(professor);       
        
    }
    public Alunos()
    {
        
    }
    
    public int search_aluno(java.util.ArrayList<Alunos> Aluno, String numero_matricula) 
    {
        int z, local = -1;
        for (z = 0; z < Aluno.size(); z++) {
            if (Aluno.get(z).getNumero_matricula().equals(numero_matricula)) {
                local = z;
            }
        }
        return local;
    }
     
     public static void printaalunos(java.util.ArrayList<Alunos> Aluno)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o numero da matricula do aluno:");
        String numero_matricula;
        Alunos aluno = new Alunos();
        numero_matricula = input.nextLine();
        System.out.println();
        int local = aluno.search_aluno(Aluno, numero_matricula);
        if (local != -1) 
        {
            System.out.println("Nome: " + Aluno.get(local).getNome());
            System.out.println("Série atual / Perido atual: " + Aluno.get(local).getSerie_atual());
            System.out.println("Idade: " + Aluno.get(local).getIdade());
            System.out.println("Email: " + Aluno.get(local).getEmail());
            System.out.println("Condição: " + Aluno.get(local).getCondicao_aluno());
            System.out.println("Coeficiente: " + Aluno.get(local).getCoeficiente_aluno());
            System.out.println("Matricula: " + Aluno.get(local).getNumero_matricula());
            System.out.println("Telefone: " + Aluno.get(local).getTelefone());
        }
        else
        {
            System.out.println("Aluno não cadastrado ou número da matricula não encontrado");
        }
    }
     
     public String getSerie_atual() {
        return serie_atual;
    }

    public void setSerie_atual(String serie_atual) {
        this.serie_atual = serie_atual;
    }
    
    public String getCoeficiente_aluno() {
        return coeficiente_aluno;
    }

    public void setCoeficiente_aluno(String coeficiente_aluno) {
        this.coeficiente_aluno = coeficiente_aluno;
    }
    
    public String getCondicao_aluno() {
        return condicao_aluno;
    }

    public void setCondicao_aluno(String condicao_aluno) {
        this.condicao_aluno = condicao_aluno;
    }
    
    public String getNumero_matricula() {
        return numero_matricula;
    }

    public void setNumero_matricula(String numero_matricula) {
        this.numero_matricula = numero_matricula;
    }

    private void printa() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
