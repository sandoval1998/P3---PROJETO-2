
package sistema_academico;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Professores extends Pessoas
{
    public String cpf;
    public String salario;
    public String graduacao;
    
    Scanner input = new Scanner(System.in);
    
    public Professores(String nome, String cpf,String idade,String email,String salario,String graduacao,String telefone)
    {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.email = email;
        this.salario = salario;
        this.graduacao = graduacao;
        this.telefone = telefone; 
        //Professor.add(professor);       
        
    }
    public Professores()
    {
        
    }
    
    public int search_professor(java.util.ArrayList<Professores> Professor, String cpf) 
    {
        int z, local = -1;
        for (z = 0; z < Professor.size(); z++) {
            if (Professor.get(z).getCpf().equals(cpf)) {
                local = z;
            }
        }
        return local;
    }
    
    public void printaprofessores(java.util.ArrayList<Professores> Professor)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o cpf do professor que você deseja ver os dados:");
        String cpf;
        Professores professor = new Professores();
        cpf = input.nextLine();
        System.out.println();
        int local = professor.search_professor(Professor, cpf);
        if (local != -1) 
        {
            System.out.println("Nome: " + Professor.get(local).getNome());
            System.out.println("Idade: " + Professor.get(local).getIdade());
            System.out.println("Email: " + Professor.get(local).getEmail());
            System.out.println("Telefone: " + Professor.get(local).getTelefone());
            System.out.println("Cpf: " + Professor.get(local).getCpf());
            System.out.println("Salario: " + Professor.get(local).getSalario());
            System.out.println("Graducao: " + Professor.get(local).getGraduacao());
        }
        else
        {
            System.out.println("Professor não cadastrado ou número do CPF não encontrado");
        }
    }
    
    public String getCpf() {
        return cpf;
    }
    
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }
    
    public String getGraduacao() {
        return graduacao;
    }

    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }
    
}
