
package sistema_academico;

import java.util.ArrayList;
import java.util.Scanner;

public class Alunos extends Pessoas
{
    //private String nome;
    private String serie_atual;
    //private int idade;
    //private String email;
    private float coeficiente_aluno;
    private String condicao_aluno;
    
    Scanner input = new Scanner(System.in);
    
    public int search_aluno(java.util.ArrayList<Alunos> Aluno, String nome) 
    {
        int z, local = -1;
        for (z = 0; z < Aluno.size(); z++) {
            if (Aluno.get(z).getNome().equals(nome)) {
                local = z;
            }
        }
        return local;
    }
     public java.util.ArrayList<Alunos> creat_aluno(Alunos aluno, java.util.ArrayList<Alunos> Aluno)
     {
        int control1 = 1, local;

        while (control1 == 1) 
        {
            int igual1 = 0, k;
            System.out.println("Digite o nome do aluno:");
            aluno.setNome(input.nextLine());
            if (Aluno.size() == 0) {
                break;
            }
            local = aluno.search_aluno(Aluno, aluno.getNome());
            if (local != -1) {
                System.out.println("Este nome ja esta sendo usado, dê um novo nome para este aluno.");
                igual1 = 1;
            }
            if (local == -1) {
                control1 = 0;
            }
        }         
        System.out.println("Digite a série do aluno:");
        aluno.setSerie_atual(input.nextLine());
        System.out.println();
        System.out.println("Digite a idade do aluno:");
        aluno.setIdade(input.nextInt());
        input.nextLine();
        System.out.println("Digite o E-mail do aluno:");
        aluno.setEmail(input.nextLine());
        System.out.println();
        System.out.println("Digite o coeficiente do aluno:");
        aluno.setCoeficiente_aluno(input.nextFloat());
        System.out.println();
        System.out.println("Digite a condição do aluno(aprovado ou reprovado):");
        aluno.setCondicao_aluno(input.nextLine());
        input.nextLine();
        System.out.println();
        System.out.println("Digite o telefone do aluno:");
        aluno.setTelefone(input.nextLine());
        System.out.println();
        
        Aluno.add(aluno);
        
        return Aluno;
        
     }
     
     public static void printaalunos(java.util.ArrayList<Alunos> Aluno)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o nome do colaborador que você deseja ver os dados:");
        String nome;
        Alunos aluno = new Alunos();
        nome = input.nextLine();
        System.out.println();
        int local = aluno.search_aluno(Aluno, nome);
        if (local != -1) 
        {
            System.out.println("Nome: " + Aluno.get(local).getNome());
            System.out.println("Série atual: " + Aluno.get(local).getSerie_atual());
            System.out.println("Idade: " + Aluno.get(local).getIdade());
            System.out.println("Email: " + Aluno.get(local).getEmail());
            System.out.println("Coeficiente: " + Aluno.get(local).getCoeficiente_aluno());
        }
    }
     
     public String getSerie_atual() {
        return serie_atual;
    }

    public void setSerie_atual(String serie_atual) {
        this.serie_atual = serie_atual;
    }
    
    public float getCoeficiente_aluno() {
        return coeficiente_aluno;
    }

    public void setCoeficiente_aluno(float coeficiente_aluno) {
        this.coeficiente_aluno = coeficiente_aluno;
    }
    
    public String getCondicao_aluno() {
        return condicao_aluno;
    }

    public void setCondicao_aluno(String condicao_aluno) {
        this.condicao_aluno = condicao_aluno;
    }

    private void printa() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
