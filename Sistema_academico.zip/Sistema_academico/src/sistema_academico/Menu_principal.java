package sistema_academico;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Menu_principal 
{

    public static void main(String[] args) 
    {
        System.out.println("----- Bem vindo ao Sistema de Gestão de Produtividade Acadêmica -----");
        System.out.println("[1] - Cadastrar Alunos;");
        System.out.println("[2] - Cadastrar Funcionários;");
        System.out.println("[3] - Cadastrar Professores;");
        System.out.println("[4] - Printar;");
        System.out.println();
        Scanner input = new Scanner(System.in);
        int opcao = input.nextInt();
        input.nextLine();
        
        java.util.ArrayList<Alunos> Aluno = new java.util.ArrayList<Alunos>();
        java.util.ArrayList<Funcionarios> Funcionario = new java.util.ArrayList<Funcionarios>();

        while(opcao != 0)
        {
            
            if(opcao == 1)
            {
                Alunos aluno = new Alunos();
                Aluno = aluno.creat_aluno(aluno, Aluno);
            }
            else if(opcao == 2)
            {
                Funcionarios funcionario = new Funcionarios();
                Funcionario = funcionario.creat_funcionario(funcionario, Funcionario);
            }
            else if(opcao == 4)
            {
                Alunos aluno = new Alunos();
                aluno.printaalunos(Aluno);
            }
            System.out.println("[1] - Cadastrar Alunos;");
            System.out.println("[1] - Cadastrar Funcionários;");
            System.out.println("[3] - Cadastrar Professores;");
            System.out.println("[4] - Printar;");
            System.out.println();
            opcao = input.nextInt();
        }
    }
    
}
