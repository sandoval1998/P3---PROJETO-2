
package sistema_academico;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Funcionarios extends Pessoas
{
    private String cpf;
    private float salario;
    private String profissao;
    
    Scanner input = new Scanner(System.in);
    
    public int search_funcionario(java.util.ArrayList<Funcionarios> Funcionario, String nome) 
    {
        int z, local = -1;
        for (z = 0; z < Funcionario.size(); z++) {
            if (Funcionario.get(z).getNome().equals(nome)) {
                local = z;
            }
        }
        return local;
    }
    
    public java.util.ArrayList<Funcionarios> creat_funcionario(Funcionarios funcionario, java.util.ArrayList<Funcionarios> Funcionario)
     {
        int control1 = 1, local;

        while (control1 == 1) 
        {
            int igual1 = 0, k;
            System.out.println("Digite o nome do funcionário:");
            funcionario.setNome(input.nextLine());
            if (Funcionario.size() == 0) 
            {
                break;
            }
            local = funcionario.search_funcionario(Funcionario, funcionario.getNome());
            if (local != -1) 
            {
                System.out.println("Este nome ja esta sendo usado, dê um novo nome para este funcionario.");
                igual1 = 1;
            }
            if (local == -1) 
            {
                control1 = 0;
            }
        }
        System.out.println("Digite o CPF do funcionário:");
        funcionario.setCpf(input.nextLine());
        System.out.println();
        System.out.println("Digite a idade do funcionário:");
        funcionario.setIdade(input.nextInt());
        input.nextLine();
        System.out.println("Digite o E-mail do funcionário:");
        funcionario.setEmail(input.nextLine());
        System.out.println();
        System.out.println("Digite o salário do funcionário:");
        funcionario.setSalario(input.nextFloat());
        System.out.println();
        System.out.println("Digite a profissão do funcionário:");
        funcionario.setProfissao(input.nextLine());
        input.nextLine();
        System.out.println();
        System.out.println("Digite o telefone do funcionário:");
        funcionario.setTelefone(input.nextLine());
        System.out.println();
        
        Funcionario.add(funcionario);
        
        return Funcionario;
     }
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    
    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }
}
